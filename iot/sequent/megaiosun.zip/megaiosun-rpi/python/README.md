
This is the python library to control [MegaIO SUN Board](https://www.sequentmicrosystems.com/megaio.html)

## Install
cd
unzip megaiosun.zip
cd /home/pi/megaiosun-rpi/python
cat README.md
sudo apt-get update
sudo apt-get install build-essential python-pip python-dev python-smbus git
cd /home/pi/megaiosun-rpi/python/megaiosun/
sudo python setup.py install



## Usage 

Now you can import the megaio library and use its functions. To test, read motors status from the MegaIO SUN board:

python
import megaiosun
megaiosun.version()
megaiosun.get_motors()


Prototypes for all functions can be found in README.md file locate under megaiosun-rpi/python/megaiosun/ directory. 

This library works with both Python2.x and Python3