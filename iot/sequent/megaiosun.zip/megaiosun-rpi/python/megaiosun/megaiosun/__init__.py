import smbus
import RPi.GPIO as GPIO 

#bus = smbus.SMBus(1)    # 0 = /dev/i2c-0 (port I2C0), 1 = /dev/i2c-1 (port I2C1)

DEVICE_ADDRESS = 0x38     #7 bit address (will be left shifted to add the read write bit)
RETRY_TIMES	= 10


RELAY_MEM_ADD = 0x00
RELAY_ON_MEM_ADD = 0x01
RELAY_OFF_MEM_ADD = 0x02


ADC_VAL_MEM_ADD = 0x03
ADC_VAL_MV_MEM_ADD = 0x0b

ROC_ID_MEM_ADD = 0x60
DIAG_TEMPERATURE_MEM_ADD = 0x72
DIAG_24V_MEM_ADD = 0x73
DIAG_5V_MEM_ADD = 0x75
DIAG_ANALOG_TEST_ADD = 0x77
REVISION_HW_MAJOR_MEM_ADD = 0x78
REVISION_HW_MINOR_MEM_ADD = 0x79
REVISION_MAJOR_MEM_ADD = 0x7a
REVISION_MINOR_MEM_ADD = 0x7b

ANALOG_TEST_ENABLE_KEY = 0xFA
RISING = 1
FALLING = 0

opto_callbacks = {}
gpio_callbacks = {}

GPIO.setmode(GPIO.BCM) 
GPIO.setup(4, GPIO.IN, pull_up_down=GPIO.PUD_UP)  
 

def version():
  print ("megaiosun python library v1.0.2 Sequent Microsystems")
  
def board():
	bus = smbus.SMBus(1)
	hmj = bus.read_byte_data( DEVICE_ADDRESS, REVISION_HW_MAJOR_MEM_ADD)
	hmi = bus.read_byte_data( DEVICE_ADDRESS, REVISION_HW_MINOR_MEM_ADD)
	fmj = bus.read_byte_data( DEVICE_ADDRESS, REVISION_MAJOR_MEM_ADD)
	fmi = bus.read_byte_data( DEVICE_ADDRESS, REVISION_MINOR_MEM_ADD)
	if(hmj <0 or hmi < 0 or fmj < 0 or fmi < 0):
		print("Fail to comm with board")
		return -1
	print("Suntrac control board v"+str(hmj)+"."+str(hmi) + " Firmaware v"+str(fmj)+"."+str(fmi))
	return 1
 
def get_proc_id():
  bus = smbus.SMBus(1)
  out = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
  s = ''
  for i in range(12):
    out[i] =  bus.read_byte_data( DEVICE_ADDRESS, ROC_ID_MEM_ADD + i)
    s+= "%02x" % out[i]
  return s  
 
def set_analog_test(value):
  bus = smbus.SMBus(1)
  if value != 0:
    bus.write_byte_data(DEVICE_ADDRESS, DIAG_ANALOG_TEST_ADD, ANALOG_TEST_ENABLE_KEY)
  else:
    bus.write_byte_data(DEVICE_ADDRESS, DIAG_ANALOG_TEST_ADD, 0)
    
def get_analog_test():
  bus = smbus.SMBus(1)
  val = bus.read_byte_data( DEVICE_ADDRESS, DIAG_ANALOG_TEST_ADD) 
  if val == ANALOG_TEST_ENABLE_KEY:
    return 1
  return 0
       
def set_motor(motor, value):
	bus = smbus.SMBus(1)
	if motor < 0:
		raise ValueError('Invalid motor number')
		return
	if motor > 2:
		raise ValueError('Invalid motor number')
		return
	if value == 0:
		bus.write_byte_data(DEVICE_ADDRESS, RELAY_OFF_MEM_ADD, motor)
	else:
		bus.write_byte_data(DEVICE_ADDRESS,  RELAY_ON_MEM_ADD, motor)

		
def set_motors(value):
	bus = smbus.SMBus(1)
	if value > 3 :
		raise ValueError('Invalid motors value')
		return
	if value < 0:
		raise ValueError('Invalid motors value')
		return
	bus.write_byte_data(DEVICE_ADDRESS, RELAY_MEM_ADD, value)
	
	
def get_motors():
	bus = smbus.SMBus(1)
	return bus.read_byte_data(DEVICE_ADDRESS, RELAY_MEM_ADD)
	
def get_adc(channel):
	outData = 0
	aux = 0
	bus = smbus.SMBus(1)
	if channel < 1 or channel > 4:
		raise ValueError('Invalid channel number')
		return
	aux = bus.read_word_data(DEVICE_ADDRESS, ADC_VAL_MEM_ADD + 2*(channel - 1))
	outData = aux #(0xff00 & (aux << 8)) + ( 0xff & (aux >> 8))
	return outData
	
def get_adc_volt(channel):
	outData = 0
	aux = 0
	bus = smbus.SMBus(1)
	if channel < 1 or channel > 4:
		raise ValueError('Invalid channel number')
		return
	aux = bus.read_word_data(DEVICE_ADDRESS, ADC_VAL_MV_MEM_ADD + 2*(channel - 1))
	outData = aux/10000.0 #(0xff00 & (aux << 8)) + ( 0xff & (aux >> 8))
	return outData
	
def get_temp():
  aux = 0
  bus = smbus.SMBus(1)       
  aux = bus.read_byte_data(DEVICE_ADDRESS, DIAG_TEMPERATURE_MEM_ADD)
  return aux
 
def get_24V():
  outData = 0
  aux = 0
  bus = smbus.SMBus(1)
	
  aux = bus.read_word_data(DEVICE_ADDRESS, DIAG_24V_MEM_ADD)
  outData = aux/1000.0 #(0xff00 & (aux << 8)) + ( 0xff & (aux >> 8))
  return outData
 
def get_5V():
  outData = 0
  aux = 0
  bus = smbus.SMBus(1)
	
  aux = bus.read_word_data(DEVICE_ADDRESS, DIAG_5V_MEM_ADD)
  outData = aux/1000.0 #(0xff00 & (aux << 8)) + ( 0xff & (aux >> 8))
  return outData 