import setuptools

with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name="megaiosun",
    version="1.0.2",
    author="Alexandru Burcea",
    author_email="olcit@gmail.com",
    description="A set of functions to control Sequent Microsystems MegaIO SUN board",
	license='MIT',
    url="https://www.sequentmicrosystems.com",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 2/3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)