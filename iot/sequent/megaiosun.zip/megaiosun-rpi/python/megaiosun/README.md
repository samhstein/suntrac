# megaiosun

This is the python library to control the MegaIO SUNTRAC IO Card
https://www.sequentmicrosystems.com

## Functions

###version()
Print the version of this library.

###board()
Print the hardware and firmware versions of the board.

### set_motor(motor, value)
Set the state of one motor.
motor: [1-2]
value: 1 = turn ON, 0 = turn OFF
Example:
	set_motor(1,1)	# turn on motor 1
	set_motor(1,0)	# turn off motor 1

### set_motors(value)
Set the state of all motors using a decimal number
value: [0-255] 
Example:
	set_motors(0) 	# turn off all motors
	set_motors(1)	# turn motor 1 on and motor 2 off
	set_motors(3)	# turn on motors 1 and 2

### get_motors()
Return the state of all motors as a decimal number
Return value: [0-255]

### get_adc(channel)
Return the value of an analog channel as a scaled decimal number
channel: [1-4]
Return value: [0-4095]; 0 = 0V, 4095 = 3.3V

### get_adc_volt(channel)
Return the value of an analog channel as a scaled voltage
channel: [1-4]
Return value: [0-3.3]; 0 = 0V, 3.3 = 3.3V

### get_temp()
Return the internal temperature of the processor in (C).

### get_24V()
Return the value of the 24V power supply in (V) with 3 decimal points.

### get_5V()
Return the value of the RPI power supply in (V) with 3 decimal points.

### get_proc_id()
Return a 24 char string representing the processor unic ID